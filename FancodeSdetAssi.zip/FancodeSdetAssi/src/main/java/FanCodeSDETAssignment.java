import java.util.List;
import java.util.Map;

import org.asynchttpclient.Response;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import io.restassured.RestAssured;
import io.restassured.response.ResponseBodyExtractionOptions;


public class FanCodeSDETAssignment {

	 @BeforeClass
	    public void setup() {
		 	RestAssured.baseURI = "http://jsonplaceholder.typicode.com";
	    }

	    @Test
	    public void testFanCodeUsersTodoCompletion() {
	        // Fetch all users
	        Response usersResponse = (Response) RestAssured.get("/users");
	        Assert.assertEquals(usersResponse.getStatusCode(), 200);

	        List<Map<String, Object>> users = ((ResponseBodyExtractionOptions) usersResponse).jsonPath().getList("");

	        for (Map<String, Object> user : users) {
	            Map<String, Object> address = (Map<String, Object>) user.get("address");
	            Map<String, Object> geo = (Map<String, Object>) address.get("geo");
	            double lat = Double.parseDouble((String) geo.get("lat"));
	            double lng = Double.parseDouble((String) geo.get("lng"));

	            if (isFanCodeCity(lat, lng)) {
	            	int userId = (int) user.get("id");
	                // Fetch todos for the user
	                Response todosResponse = (Response) RestAssured.get("/todos?userId=" + userId);
	                Assert.assertEquals(todosResponse.getStatusCode(), 200);

	                List<Map<String, Object>> todos = ((ResponseBodyExtractionOptions) todosResponse).jsonPath().getList("");
	                long completedTasks = todos.stream().filter(todo -> (boolean) todo.get("completed")).count();
	                long totalTasks = todos.size();

	                Assert.assertTrue(totalTasks > 0);
	                double completionPercentage = (double) completedTasks / totalTasks * 100;

	                Assert.assertTrue(completionPercentage > 50);
	            }
	        }
	    }

	    private boolean isFanCodeCity(double lat, double lng) {
	        return lat >= -40 && lat <= 5 && lng >= 5 && lng <= 100;
	    }
}
